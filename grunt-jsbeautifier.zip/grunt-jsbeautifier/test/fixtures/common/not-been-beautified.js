/* jshint unused: false */
var temp = {
 hello: 1,
    world: 2
};

var foo=temp||
    {};